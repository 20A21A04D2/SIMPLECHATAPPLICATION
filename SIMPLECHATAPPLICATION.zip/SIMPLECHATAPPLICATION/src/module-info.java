/**
 * 
 */
/**
 * 
 */
module SIMPLECHATAPPLICATION {
	requires java.sql;
	requires java.desktop;
}